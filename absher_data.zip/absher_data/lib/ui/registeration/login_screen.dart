import 'package:flutter/material.dart';

import '../../helpers/constants.dart';
import '../../helpers/public_methods.dart';
import '../common_widgets/rounded_center_button.dart';
import '../common_widgets/rounded_text_field.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool checkBoxValue = false;

  void onBoxChanged(val) {
    setState(() {
      checkBoxValue = val;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: mainColor,
        toolbarHeight: 0,
      ),
      body: SingleChildScrollView(
        child: SizedBox(
          width: getWidth(context),
          child: Column(
            // mainAxisAlignment: MainAxisAlignment.center,
            // crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                height: getHeight(context) * 0.07,
              ),
              Image.asset(
                'assets/images/app_logo.png',
                width: 120,

                // height: 140,
              ),
              SizedBox(
                height: 25,
              ),
              Text(
                "Sign in to continue",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: mediumGreyFontColor,
                    fontSize: 16,
                    fontWeight: FontWeight.w600),
              ),
              SizedBox(
                height: 30,
              ),
              RoundedTextField(
                label: "Phone",
                icon: Icons.phone,
              ),
              SizedBox(
                height: 2,
              ),
              RoundedTextField(
                label: "Password",
                icon: Icons.lock,
              ),
              SizedBox(
                height: 2,
              ),
              Row(
                children: [
                  SizedBox(
                    width: 26,
                  ),
                  Checkbox(
                    shape: CircleBorder(),
                    value: checkBoxValue,
                    onChanged: onBoxChanged,
                    checkColor: mainColor,
                  ),
                  Text(
                    "Remember me",
                    style: TextStyle(
                        color: darkGreyColor, fontWeight: FontWeight.w500),
                  )
                ],
              ),
              SizedBox(
                height: 0,
              ),
              // Spacer(),

              RoundedCenterButtton(
                  onPressed: () {
                    Navigator.pushNamed(context, "home_screen");
                  },
                  title: "Log in"),
              TextButton(
                  onPressed: () {},
                  child: Text(
                    "Forgot Password?",
                    style: TextStyle(
                        color: mainColor, fontWeight: FontWeight.w500),
                  )),

              Text(
                "Log in with",
                style: TextStyle(
                    color: mediumGreyColor, fontWeight: FontWeight.w500),
              ),
              SizedBox(
                height: 10,
              ),
              RoundedSocialMediaButtton(
                  onPressed: () {
                  },
                  title: "Continue with facebook", imageIcon: "assets/icons/facebook_icon.png", color: facebookColor,),
              SizedBox(
                height: 10,
              ),
              RoundedSocialMediaButtton(
                onPressed: () {
                },
                title: "Continue with Gmail", imageIcon: "assets/icons/google_icon.png", color: googleColor,),
              SizedBox(
                height: 15,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Don't have an account yet?",
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.w400, fontSize: 15),
                  ),
                  TextButton(
                      onPressed: () {
                        Navigator.pushNamed(context, "signup_screen");
                      },
                      child: Text(
                        "Sign Up?",
                        style: TextStyle(
                            color: mainColor, fontWeight: FontWeight.w500),
                      )),
                ],
              ),

              // SizedBox(
              //   height: getHeight(context) * 0.15,
              // )
            ],
          ),
        ),
      ),
    );
  }
}
