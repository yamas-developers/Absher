import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../../helpers/constants.dart';
import '../common_widgets/rounded_center_button.dart';
import '../common_widgets/rounded_text_field_filled.dart';

class ExpressDetailsScreen extends StatefulWidget {
  const ExpressDetailsScreen({Key? key}) : super(key: key);

  @override
  State<ExpressDetailsScreen> createState() => _ExpressDetailsScreenState();
}

class _ExpressDetailsScreenState extends State<ExpressDetailsScreen> {
  String pickupAddress = "Sinaa St. Doha, Qatar";
  String deliveryAddress = "7FJX*H Doha, Qatar";
  List categories = ["Documents", "Food", "Personal Stuff", "Clothes", "Sensitive Items"];
  String selected = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 0,
        backgroundColor: mainColor,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 6,
              ),
              Container(
                padding: EdgeInsets.fromLTRB(0, 15, 18, 0),
                child: Flex(
                  direction: Axis.horizontal,
                  children: [
                    Expanded(
                      flex: 1,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          GestureDetector(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Image.asset(
                              "assets/icons/back_arrow_icon.png",
                              width: 24,
                              height: 24,
                            ),
                          ),
                          SizedBox(
                            width: 8,
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 8,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Flexible(
                              child: Text(
                            "Enter Details",
                            style: TextStyle(
                                fontSize: 18,
                                color: mainColor,
                                fontWeight: FontWeight.w500),
                          )),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 15,
              ),
              ExpressDetailItem(address: pickupAddress, title: "Pick-up"),
              SizedBox(
                height: 15,
              ),
              ExpressDetailItem(address: deliveryAddress, title: "Delivery"),
              SizedBox(height: 15,),
              Text(
                'Describe the item',
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 18,
                    fontWeight: FontWeight.w700),
              ),
              SizedBox(height: 10,),
              RoundedTextFieldFilled(label: "Tell us more ...", maxLines: 2,),
              SizedBox(height: 10,),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 0),
                height: 50,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    ...List.generate(
                      categories.length,
                          (i) => GestureDetector(
                        onTap: () {
                          setState(() {
                            selected = categories[i];
                          });
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 4, vertical: 8),
                          child: Container(
                            decoration: BoxDecoration(
                                color: categories[i] == selected
                                    ? mainColor
                                    : mainColorLight
                                    .withOpacity(0.15),
                                borderRadius:
                                BorderRadius.circular(6)),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Center(
                                  child: Text(
                                    "${categories[i]}",
                                    style: TextStyle(
                                        color:
                                        categories[i] == selected
                                            ? Colors.white
                                            : darkGreyColor),
                                  )),
                            ),
                          ),
                        ),
                      ),
                    ).toList(),
                  ],
                ),
              ),
              // Spacer(),
              Divider(),
              if (pickupAddress != "" && deliveryAddress != "")
                Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "QAR",
                          style: TextStyle(
                              fontSize: 15,
                              color: mainColor,
                              fontWeight: FontWeight.w400),
                        ),
                        SizedBox(
                          width: 4,
                        ),
                        Text(
                          "30",
                          style: TextStyle(
                              fontSize: 18,
                              color: mainColor,
                              fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    Text(
                      "Pick-up at: 2:30 pm | Delivery at: 9:30 pm",
                      style: TextStyle(
                          fontSize: 13,
                          color: mediumGreyColor,
                          fontWeight: FontWeight.w400),
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    RoundedCenterButtton(
                      title: "Go to Checkout",
                      onPressed: () {},
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                          text: 'By clicking \'Go to Checkout\' you agree with our list of ',
                          style: TextStyle(
                              color: mediumGreyColor,
                              fontSize: 12,
                              // fontWeight: FontWeight.bold
                          ),
                          children: <TextSpan>[
                            TextSpan(text: 'Prohibited Items',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    decoration: TextDecoration.underline),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {
                                    // open desired screen
                                  }
                            ),
                            TextSpan(
                                text: ' and ',
                                style: TextStyle(color: mediumGreyColor,
                                    fontSize: 12,
                                    // fontWeight: FontWeight.bold
                                )
                            ),
                            TextSpan(
                                text: 'Terms & Conditions,',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    decoration: TextDecoration.underline),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {
                                    // open desired screen
                                  }
                            ),
                          ]
                      ),
                    )
                  ],
                )
              else
                Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 8.0, horizontal: 20),
                  child: Text(
                    "Please select locations to see the price and delivery time",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12),
                  ),
                ),
              SizedBox(
                height: 35,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ExpressDetailItem extends StatelessWidget {
  const ExpressDetailItem({
    Key? key,
    required this.address,
    required this.title,
  }) : super(key: key);

  final String address;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

      Text(
        '${title}',
        style: TextStyle(
            color: Colors.black,
            fontSize: 18,
            fontWeight: FontWeight.w700),
      ),
      SizedBox(
        height: 2,
      ),
      Text(
        '${address}',
        style: TextStyle(
            color: Colors.black,
            fontSize: 16,
            fontWeight: FontWeight.w500),
      ),
      SizedBox(
        height: 15,
      ),
      Row(
        children: [
          Expanded(child: RoundedTextFieldFilled(label: "Name")),
          SizedBox(
            width: 6,
          ),
          Container(
            padding: EdgeInsets.symmetric(vertical: 12, horizontal: 10),
            decoration: BoxDecoration(
                color: lightestGreyColor,
                borderRadius: BorderRadius.circular(10)),
            child: Icon(Icons.perm_contact_calendar_sharp, color: mediumGreyColor.withOpacity(0.8),),
          )
        ],
      ),
      SizedBox(height: 10,),
      RoundedTextFieldFilled(label: "Phone"),
      SizedBox(height: 10,),
      RoundedTextFieldFilled(label: "Address Details (optional)", maxLines: 3,),
    ],);
  }
}
