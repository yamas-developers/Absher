import 'package:absher/helpers/constants.dart';
import 'package:absher/helpers/route_constants.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../helpers/public_methods.dart';
import '../common_widgets/nearest_restaurant_item.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _current = 0;

  getPageData() async {
    // FocusScope.of(context).requestFocus(FocusNode());
  }

  @override
  void initState() {
    getPageData();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // SystemChrome.setPreferredOrientations([
    //   DeviceOrientation.portraitUp,
    //   // DeviceOrientation.portraitDown,
    // ]);
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 4,
            ),
            Container(
              height: getHeight(context) * 0.1,
              padding: EdgeInsets.fromLTRB(18, 10, 18, 0),
              child: Flex(
                direction: Axis.horizontal,
                children: [
                  Expanded(
                    flex: 6,
                    child: Container(
                      // height: 39,
                      padding: EdgeInsets.fromLTRB(8, 9, 4, 9),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Color.fromRGBO(0, 0, 0, 0.15),
                              blurRadius: 6,
                              spreadRadius: .1,
                            ),
                          ]),
                      child: Row(
                        children: [
                          Image.asset(
                            "assets/icons/location_pin.png",
                            width: 20,
                            height: 20,
                            color: mainColor,
                          ),
                          SizedBox(
                            width: 6,
                          ),
                          Flexible(
                              child: Text(
                            "Location",
                            style: TextStyle(
                                fontSize: 16,
                                color: Color.fromRGBO(120, 22, 145, 1),
                                fontWeight: FontWeight.w600),
                          )),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.pushNamed(context, notifications_screen);
                          },
                          child: Image.asset(
                            "assets/icons/notification.png",
                            width: 24,
                            height: 24,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 8,
            ),
            Container(
              height: getHeight(context) * 0.15,
              padding: const EdgeInsets.all(8.0),
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  CarouselSlider(
                    options: CarouselOptions(
                      height:
                          getSize(context, 0.30, getWidth(context) * .40, 120),
                      // aspectRatio: 16/9,
                      viewportFraction: .8,
                      initialPage: 0,
                      enableInfiniteScroll: true,
                      reverse: false,
                      autoPlay: true,
                      autoPlayInterval: Duration(seconds: 3),
                      autoPlayAnimationDuration: Duration(milliseconds: 800),
                      autoPlayCurve: Curves.fastOutSlowIn,
                      enlargeCenterPage: true,
                      onPageChanged: (int i, a) {
                        _current = i;
                        setState(() {});
                      },
                      scrollDirection: Axis.horizontal,
                    ),
                    items: [
                      Container(
                        width: getWidth(context),
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: Stack(
                              alignment: Alignment.bottomCenter,
                              children: [
                                Image.asset(
                                  'assets/images/banner1.jpeg',
                                  width: getWidth(context),
                                  fit: BoxFit.cover,
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                          end: Alignment.bottomCenter,
                                          begin: Alignment.topCenter,
                                          colors: [
                                        Color.fromRGBO(188, 55, 222, 0),
                                        Color.fromRGBO(188, 55, 222, 0),
                                        Color.fromRGBO(120, 22, 145, 0.82),
                                      ])),
                                )
                              ],
                            )),
                      ),
                      Container(
                        width: getWidth(context),
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: Stack(
                              alignment: Alignment.bottomCenter,
                              children: [
                                Image.asset(
                                  'assets/images/banner2.jpeg',
                                  width: getWidth(context),
                                  fit: BoxFit.cover,
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                          end: Alignment.bottomCenter,
                                          begin: Alignment.topCenter,
                                          colors: [
                                        Color.fromRGBO(188, 55, 222, 0),
                                        Color.fromRGBO(188, 55, 222, 0),
                                        Color.fromRGBO(120, 22, 145, 0.82),
                                      ])),
                                )
                              ],
                            )),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [0, 1, 2].map(
                      (index) {
                        return Container(
                          width: 8.0,
                          height: 8.0,
                          margin: EdgeInsets.symmetric(
                              vertical: 10.0, horizontal: 2.0),
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _current == index
                                  ? Color.fromRGBO(239, 0, 255, 1.0)
                                  : Color.fromRGBO(252, 227, 255, 1.0)),
                        );
                      },
                    ).toList(),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 8,
            ),
            Container(
              height: getHeight(context) * 0.045,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                "Welcome to Absher",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),

            Container(
              width: getWidth(context),
              height: getHeight(context) * 0.172,
              padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
              child: Row(
                children: [
                  Expanded(
                    child: buildSlideTransition(HomeItemWidget(
                        onPress: () {
                          Navigator.pushNamed(context, restaurant_screen);
                        },
                        image: 'assets/images/type1.png',
                        title: 'Restaurant'), 400),
                  ),
                  SizedBox(
                    width: 12,
                  ),
                  Expanded(
                    child: buildSlideTransition(HomeItemWidget(
                        onPress: () {
                          //go to store
                          Navigator.pushNamed(context, restaurant_screen,
                              arguments: {"screen_type": "store"});
                        },
                        image: 'assets/images/store.png',
                        title: 'Store'), 400, startPos: 2.0),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16,),
            Padding(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
              child: Row(children: [
                Expanded(
                  child: buildSlideTransition(HomeItemBanner(
                      onPress: () {
                        Navigator.pushNamed(context, express_delivery_screen);
                      },
                      image: 'assets/images/express_delivery_image.jpg',
                      title: 'Absher Express'),1000, startPos: -2.0),
                ),
              ]),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              width: getWidth(context),
              height: getHeight(context) * 0.172,
              padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
              child: Row(
                children: [
                  Expanded(
                    child: buildSlideTransition(HomeItemWidget(
                        onPress: () {},
                        image: 'assets/images/pharmacy.png',
                        title: 'Pharmacy'), 400),
                  ),
                  SizedBox(
                    width: 12,
                  ),
                  Expanded(
                    child: buildSlideTransition(HomeItemWidget(
                        onPress: () {
                          Navigator.pushNamed(context, services_screen);
                        },
                        image: 'assets/images/service.png',
                        title: 'Services'), 400, startPos: 2.0),
                  ),
                ],
              ),
            ),
            // Container(
            //
            //   height: getHeight(context)/getWidth(context)*140,
            //   // constraints: BoxConstraints.expand(),
            //   // height: getHeight(context),
            //   padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
            //   child: GridView.count(
            //     shrinkWrap: true,
            //     physics: NeverScrollableScrollPhysics(),
            //     crossAxisCount: 2,
            //     crossAxisSpacing: 8,
            //     mainAxisSpacing: 10,
            //     childAspectRatio: getHeight(context)/getWidth(context)*0.6,
            //     // childAspectRatio: 1.2,
            //     children: [
            //
            //
            //     ],
            //   ),
            // ),
            SizedBox(
              height: 24,
            ),
            Container(
              height: getHeight(context) * 0.03,
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Text(
                "Top Picks",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(
              height: 2,
            ),
            Container(
              padding: EdgeInsets.only(left: 6, right: 18),
              height: getHeight(context) * 0.18,
              child: Row(
                // scrollDirection: Axis.horizontal,
                children: [
                  Expanded(
                    child: HomeTopPickItems(
                        onPress: () {},
                        image: 'assets/icons/past_order.png',
                        title: "Past Order"),
                  ),
                  // SizedBox(width: 8,),
                  Expanded(
                    child: HomeTopPickItems(
                        onPress: () {},
                        image: 'assets/icons/happy_hours.png',
                        title: "Past Order"),
                  ),
                  // SizedBox(width: 8,),
                  Expanded(
                    child: HomeTopPickItems(
                        onPress: () {},
                        image: 'assets/icons/offers.png',
                        title: "Offers"),
                  ),
                  // SizedBox(width: 8,),
                  Expanded(
                    child: HomeTopPickItems(
                        onPress: () {},
                        image: 'assets/icons/choices.png',
                        title: "Choices"),
                  ),
                  // SizedBox(width: 8,),
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Resturents nearby",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    "View All",
                    style: TextStyle(
                      color: Color.fromRGBO(155, 28, 187, 1),
                    ),
                  )
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 6),
              width: getWidth(context),
              height: 200,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  NearestResturentItem(
                    onPress: () {},
                    image: 'assets/images/home_img1.png',
                    title: 'Lorem Ipsum',
                    distance: "9.5",
                    placeName: "Place Name",
                    rating: "4.6",
                    timeDuration: "40-50",
                    price: "2",
                    centerImageheight: 110,
                    maxWidth: 300,
                    widthFraction: 0.7,
                  ),
                  SizedBox(
                    width: 8,
                  ),
                  NearestResturentItem(
                    onPress: () {},
                    image: 'assets/images/home_img1.png',
                    title: 'Lorem Ipsum',
                    distance: "9.5",
                    placeName: "Place Name",
                    rating: "4.6",
                    timeDuration: "40-50",
                    price: "2",
                    centerImageheight: 110,
                    maxWidth: 300,
                    widthFraction: 0.7,
                  ),
                  SizedBox(
                    width: 8,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            // HomeItemWidget(onPress: (){}, image: 'assets/images/type1.png', title: 'Restaurant'),
          ],
        ),
      ),
    );
  }
}

class HomeItemWidget extends StatelessWidget {
  final onPress;
  final String image;
  final String title;

  const HomeItemWidget(
      {Key? key,
      required this.onPress,
      required this.image,
      required this.title})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPress,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Stack(
          children: [
            Container(
              width: getWidth(context),
              height: 300,
              child: Image.asset(
                '${image}',
                // fit: BoxFit.cover,
              ),
            ),
            Container(
              width: getWidth(context),
              height: 300,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      end: Alignment.bottomCenter,
                      begin: Alignment.topCenter,
                      colors: [
                    Color.fromRGBO(188, 55, 222, 0),
                    Color.fromRGBO(188, 55, 222, 0),
                    Color.fromRGBO(120, 22, 145, 0.82),
                  ])),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Align(
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    "${title}",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HomeItemBanner extends StatelessWidget {
  final onPress;
  final String image;
  final String title;

  const HomeItemBanner(
      {Key? key,
      required this.onPress,
      required this.image,
      required this.title})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPress,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Stack(
          children: [
            Container(
              width: getWidth(context),
              height: 110,
              child: Image.asset(
                '${image}',
                fit: BoxFit.fitWidth,
              ),
            ),
            Container(
              width: getWidth(context),
              height: 110,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      end: Alignment.bottomCenter,
                      begin: Alignment.topCenter,
                      colors: [
                    Color.fromRGBO(188, 55, 222, 0),
                    Color.fromRGBO(188, 55, 222, 0),
                    Color.fromRGBO(120, 22, 145, 0.82),
                  ])),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Align(
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    "${title}",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HomeTopPickItems extends StatelessWidget {
  final Function onPress;
  final String image;
  final String title;

  const HomeTopPickItems(
      {Key? key,
      required this.onPress,
      required this.image,
      required this.title})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8.0, 8, 0, 8),
      child: Column(
        children: [
          Container(
            width: getWidth(context) * 0.25,
            height: getHeight(context) * 0.1,
            padding: EdgeInsets.all(18),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(
                    // rgba(155, 28, 187, 0.25)
                    color: Color.fromRGBO(155, 28, 187, 0.25),
                    spreadRadius: .4,
                    blurRadius: 4,
                  ),
                ]),
            child: Image.asset(
              '$image',
              fit: BoxFit.fitWidth,
              // width: 40,
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            "$title",
            style: TextStyle(
              color: Color.fromRGBO(120, 22, 145, 1),
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          )
        ],
      ),
    );
  }
}

// class NearestResturentItem1 extends StatelessWidget {
//   final Function onPress;
//   final String image;
//   final String title;
//
//   const NearestResturentItem1(
//       {Key? key,
//       required this.onPress,
//       required this.image,
//       required this.title})
//       : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.fromLTRB(12.0, 8, 0, 8),
//       child: Column(
//         children: [
//           Container(
//             width: getSize(context, .7, 300, 0),
//             // height: 160,
//             padding: EdgeInsets.all(10),
//             decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.circular(16),
//                 boxShadow: [
//                   BoxShadow(
//                     // rgba(155, 28, 187, 0.25)
//                     color: Color.fromRGBO(0, 0, 0, 0.2),
//                     spreadRadius: .2,
//                     blurRadius: 2,
//                   ),
//                 ]),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     Flexible(
//                       child: Text(
//                         "$title",
//                         maxLines: 1,
//                         style: TextStyle(
//                           overflow: TextOverflow.ellipsis,
//                           color: Color.fromRGBO(120, 22, 145, 1),
//                           fontSize: 14,
//                           fontWeight: FontWeight.w500,
//                         ),
//                       ),
//                     ),
//                     Row(
//                       children: [
//                         Image.asset(
//                           "assets/icons/location_pin_grey.png",
//                           width: 16,
//                           height: 16,
//                         ),
//                         Container(
//                           width: 80,
//                           child: Text(
//                             "Place Name",
//                             maxLines: 1,
//                             style: TextStyle(
//                               overflow: TextOverflow.ellipsis,
//                               fontSize: 12,
//                             ),
//                           ),
//                         ),
//                       ],
//                     )
//                   ],
//                 ),
//                 SizedBox(
//                   height: 8,
//                 ),
//                 ClipRRect(
//                   borderRadius: BorderRadius.circular(16),
//                   child: Stack(
//                     alignment: Alignment.bottomLeft,
//                     children: [
//                       Image.asset(
//                         '$image',
//                         width: getWidth(context),
//                         height: 110,
//                         fit: BoxFit.cover,
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 8, bottom: 2.0),
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Container(
//                               padding: EdgeInsets.fromLTRB(6, 2, 6, 2),
//                               decoration: BoxDecoration(
//                                 color: Color.fromRGBO(155, 28, 187, 0.85),
//                                 borderRadius: BorderRadius.circular(4),
//                               ),
//                               child: Row(
//                                 mainAxisSize: MainAxisSize.min,
//                                 children: [
//                                   Image.asset(
//                                     "assets/icons/star.png",
//                                     width: 14,
//                                     height: 14,
//                                   ),
//                                   SizedBox(
//                                     width: 2,
//                                   ),
//                                   Text(
//                                     "4.6",
//                                     style: TextStyle(
//                                         fontSize: 12, color: Colors.white),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                             SizedBox(
//                               height: 6,
//                             ),
//                             Flex(
//                               direction: Axis.horizontal,
//                               children: [
//                                 Expanded(
//                                   flex: 3,
//                                   child: Row(
//                                     mainAxisSize: MainAxisSize.min,
//                                     children: [
//                                       Image.asset(
//                                         "assets/icons/time.png",
//                                         width: 16,
//                                         height: 16,
//                                       ),
//                                       SizedBox(
//                                         width: 2,
//                                       ),
//                                       Flexible(
//                                         child: Text(
//                                           "40-50 Mints",
//                                           maxLines: 1,
//                                           style: TextStyle(
//                                               overflow: TextOverflow.ellipsis,
//                                               fontSize: 12,
//                                               color: Colors.white),
//                                         ),
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                                 Expanded(
//                                   flex: 2,
//                                   child: Row(
//                                     mainAxisSize: MainAxisSize.min,
//                                     children: [
//                                       Image.asset(
//                                         "assets/icons/kilometer.png",
//                                         width: 16,
//                                         height: 16,
//                                       ),
//                                       SizedBox(
//                                         width: 2,
//                                       ),
//                                       Flexible(
//                                         child: Text(
//                                           "9.5 km",
//                                           maxLines: 1,
//                                           style: TextStyle(
//                                             overflow: TextOverflow.ellipsis,
//                                               fontSize: 12, color: Colors.white),
//                                         ),
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                                 Expanded(
//                                   flex: 2,
//                                   child: Row(
//                                     mainAxisSize: MainAxisSize.min,
//                                     children: [
//                                       Image.asset(
//                                         "assets/icons/rider.png",
//                                         width: 22,
//                                         height: 22,
//                                       ),
//                                       SizedBox(
//                                         width: 2,
//                                       ),
//                                       Text(
//                                         "\$2",
//                                         style: TextStyle(
//                                             fontSize: 12, color: Colors.white),
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                               ],
//                             )
//                           ],
//                         ),
//                       )
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           // SizedBox(
//           //   height: 10,
//           // ),
//         ],
//       ),
//     );
//   }
// }
