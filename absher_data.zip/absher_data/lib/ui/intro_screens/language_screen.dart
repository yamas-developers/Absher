import 'package:absher/helpers/constants.dart';
import 'package:flutter/material.dart';

import '../../helpers/public_methods.dart';
import '../common_widgets/rounded_center_button.dart';

class LanguageScreen extends StatefulWidget {
  const LanguageScreen({Key? key}) : super(key: key);

  @override
  State<LanguageScreen> createState() => _LanguageScreenState();
}

class _LanguageScreenState extends State<LanguageScreen> {
  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: mainColor,
        toolbarHeight: 0,
      ),
      body: Stack(
        children: [
          Align(
            alignment: Alignment.bottomCenter,
            child: Image.asset(
              'assets/images/language_screen_bg.png',
              // width: 130,

              // height: 140,
            ),
          ),
          SizedBox(
            width: getWidth(context),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.center,
              // crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: getHeight(context)*0.13,),
                Image.asset(
                  'assets/images/app_logo.png',
                  width: 130,

                  // height: 140,
                ),
                SizedBox(height: 35,),
                Text("Select Your Language and Location",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: mainColor,
                      fontSize: 16,
                      fontWeight: FontWeight.w600
                  ),),
                SizedBox(height: 40,),
                GestureDetector(
                  onTap: (){},
                  child: Container(
                    width: getWidth(context)-66,
                    padding: EdgeInsets.symmetric(vertical: 16, horizontal: 0),
                    decoration: BoxDecoration(
                        color: mainColor.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(20),
                        gradient: LinearGradient(
                            colors: [mainColor, mainColorLight.withOpacity(0.8)]
                            ,begin: Alignment.topCenter,
                            end: Alignment.bottomCenter
                        ),
                        boxShadow: [
                          BoxShadow(
                              color: darkGreyColor.withOpacity(0.2),
                              offset: Offset(0, 2),
                              blurRadius: 8)
                        ]
                    ),
                    child: Row(
                      children: [
                        SizedBox(width: 30,),
                        Text("English",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w600
                          ),),
                        Spacer(),
                        Image.asset("assets/icons/arrow_down.png", height: 20,),
                        SizedBox(width: 20,),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 30,),
                GestureDetector(
                  onTap: (){},
                  child: Container(
                    width: getWidth(context)-66,
                    padding: EdgeInsets.symmetric(vertical: 16, horizontal: 0),
                    decoration: BoxDecoration(
                        color: mainColor.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(20),
                        gradient: LinearGradient(
                            colors: [mainColor, mainColorLight.withOpacity(0.8)]
                            ,begin: Alignment.topCenter,
                            end: Alignment.bottomCenter
                        ),
                        boxShadow: [
                          BoxShadow(
                              color: darkGreyColor.withOpacity(0.2),
                              offset: Offset(0, 2),
                              blurRadius: 8)
                        ]
                    ),
                    child: Row(
                      children: [
                        SizedBox(width: 14,),
                        Image.asset("assets/icons/pin.png", height: 20,),
                        SizedBox(width: 15,),
                        Text("Address",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w600
                          ),),

                      ],
                    ),
                  ),
                ),
                Spacer(),

                RoundedCenterButtton(onPressed: (){
                  Navigator.pushNamed(context, "login_screen");
                }, title: "Done"),
                SizedBox(height: getHeight(context)*0.15,)
              ],
            ),
          ),
        ],
      ),
    );
  }
}
