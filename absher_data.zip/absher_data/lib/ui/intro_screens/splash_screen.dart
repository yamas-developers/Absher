import 'package:absher/helpers/constants.dart';
import 'package:flutter/material.dart';

import '../../helpers/public_methods.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    Future.delayed(Duration(seconds: 5)).then((value) => Navigator.pushNamed(context, "language_screen"));
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: mainColor,
        toolbarHeight: 0,
      ),
      body: Container(
        height: getHeight(context),
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/images/splash_screen_bg.png"))),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Image.asset(
                'assets/images/app_logo.png',
                width: 180,
                // height: 140,
              ),
            ),
            SizedBox(height: 50,)
          ],
        ),
      ),
    );
  }
}
