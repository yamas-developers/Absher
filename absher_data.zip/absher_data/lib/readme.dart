
//Here are the packages used in this project

//carousel_slider: ^4.1.1
//dotted_border: ^2.0.0+3
