import 'package:flutter/material.dart';

double getSize(
    BuildContext context, double width, double maxWidth, double minWidth) {
  double mwidth = MediaQuery.of(context).size.width * width;
  print("width -> ${mwidth}->maxWidth ${maxWidth}-> minWidth ${minWidth}");
  double size = mwidth;
  if (mwidth > maxWidth) {
    size = maxWidth;
  }
  if (mwidth < minWidth) {
    size = minWidth;
  }
  print("siax as ${size}");
  return size;
}

getWidth(context) {
  return MediaQuery.of(context).size.width;
}

getHeight(context) {
  return MediaQuery.of(context).size.height;
}

showAlertDialog(context, title, message,
    {okButtonText = 'Ok',
      onPress = null,
      showCancelButton = true,
      dismissible = true}) {
  String icon;
  showGeneralDialog(
      context: context,
      barrierLabel: "Barrier",
      barrierDismissible: dismissible,
      barrierColor: Colors.black.withOpacity(0.5),
      transitionDuration: Duration(milliseconds: 400),
      transitionBuilder: (_, anim, __, child) {
        var begin = 0.5;
        var end = 1.0;
        var curve = Curves.bounceOut;
        if (anim.status == AnimationStatus.reverse) {
          curve = Curves.fastLinearToSlowEaseIn;
        }
        var tween =
        Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
        return ScaleTransition(
          scale: anim.drive(tween),
          child: child,
        );
      },
      pageBuilder: (BuildContext alertContext, Animation<double> animation,
          Animation<double> secondaryAnimation) {
        return WillPopScope(
          onWillPop: () {
            return Future.value(dismissible);
          },
          child: Center(
            child: Container(
              margin: EdgeInsets.all(16),
              child: SingleChildScrollView(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Material(
                    child: Container(
                      padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                      color: Colors.white,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: 4,
                          ),
                          Center(
                            child: Image.asset(
                              'assets/icons/tick_filled_icon.png',
                              width: 50,
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Text(
                            "${title}",
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 8.0, right: 8),
                            child: Text("$message"),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              if (showCancelButton)
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(alertContext).pop();
                                  },
                                  child: Text("Cancel"),
                                ),
                              if (onPress != null)
                                TextButton(
                                  onPressed: onPress,
                                  child: Text("$okButtonText"),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      });
}

buildSlideTransition(child, animationDuration, {startPos = 1.0, endPos = 0.0, curve = Curves.easeInOut}){
  animationDuration += 300;
  return TweenAnimationBuilder(
    tween: Tween<Offset>(begin: Offset(startPos, 0), end: Offset(endPos, 0)),
    duration: Duration(milliseconds: animationDuration),
    curve: curve,
    builder: (context, Offset offset, child) {
      return FractionalTranslation(
        translation: offset,
        child: child,
      );
    },
    child: child,
  );
}
